-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Май 24 2021 г., 11:49
-- Версия сервера: 8.0.19
-- Версия PHP: 8.0.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `diplom-tt`
--

-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` bigint UNSIGNED NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `task_id` bigint UNSIGNED NOT NULL,
  `project_id` bigint UNSIGNED NOT NULL,
  `company_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `companies`
--

CREATE TABLE `companies` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `companies`
--

INSERT INTO `companies` (`id`, `name`, `is_active`, `code`, `created_at`, `updated_at`) VALUES
(1, 'OyrBcZZFp5', 1, 'rcnGgjp6fWIK0ErlFMj0sNGbE1vbNntlMtB9XZSGqxvCaCrSES', NULL, NULL),
(2, 'RpnPbYmopu', 1, 'axGTgWdIUWcLT0x7cwsRHx1Kd43usyRzTcpc5NmBOhlulUwril', NULL, NULL),
(3, 'BKtGLCqBm5', 1, 'hKweLfFdv9MrRPwwz2FbcEj9AbA80RcpBHOvjuKFD8ie7ki4dD', NULL, NULL),
(4, 'SzwELhC4wC', 1, 'mAKv9FJNOACnJ2Ded7jbIvzQgE9XTbwXh7OrmuDmG4jWduocSf', NULL, NULL),
(5, 'KPnw8zu5tO', 1, 'Ot1uAwWFLEL8a5cjZghy6X3bqASp2wPA1VP7JbaHm3ZhW8GcDU', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `files`
--

CREATE TABLE `files` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

CREATE TABLE `migrations` (
  `id` int UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_04_03_095123_create_projects_table', 1),
(5, '2021_04_03_095156_create_tasks_table', 1),
(6, '2021_04_03_095220_create_companies_table', 1),
(7, '2021_04_03_095234_create_roles_table', 1),
(8, '2021_04_03_095255_create_comments_table', 1),
(9, '2021_04_03_104709_create_roles_tasks_table', 1),
(10, '2021_04_03_105244_create_task_status_table', 1),
(11, '2021_04_03_105719_create_task_timer_table', 1),
(12, '2021_04_03_111309_create_files_table', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `projects`
--

CREATE TABLE `projects` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `budget` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `projects`
--

INSERT INTO `projects` (`id`, `name`, `budget`, `text`, `is_active`, `code`, `company_id`, `created_at`, `updated_at`) VALUES
(1, 'Таск Трекер', '100', 'Разработка сайта Таск Трекер', 1, 'TCQLofjwgJlZ0cHT4G5mR58J4wzOiRdrnfCJ9NyTU5Y4epK7HT', 1, NULL, NULL),
(2, 'ХТК', '75000', 'Разработка сайта ХТК', 1, 'ta33Y9GmAVPPEyC4Mjbuwyu1HfDh4qKUNsSrseMxiVKq3OkiGU', 1, NULL, NULL),
(3, 'Серебряный шар (приложение)', '70000', 'Разработка приложения Серебряный шар', 1, 'oQWkhTX8NUmAnDgBuNpbQOulaE19hvi8BTJP3NYd73c4G62S2M', 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `roles`
--

CREATE TABLE `roles` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles`
--

INSERT INTO `roles` (`id`, `name`, `is_active`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Постановщик', 1, '9wjleRnKl1bGG8F88S8cnG8J1p4Ho70GDKKkadRimaJPmGUSvs', NULL, NULL),
(2, 'Исполнитель', 1, 'sP9vjLjUF1PNf4hJm9qcUqdbW5Sg7PK4SLKmWcvut54uVFaymH', NULL, NULL),
(3, 'Заказчик', 1, 'dXiodcgc5HAmhq8qUxMnPkkgEdKY4yKvyz0iI73jf1Aj0nEzcK', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `roles_tasks`
--

CREATE TABLE `roles_tasks` (
  `id` bigint UNSIGNED NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  `task_id` bigint UNSIGNED NOT NULL,
  `project_id` bigint UNSIGNED NOT NULL,
  `company_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `roles_tasks`
--

INSERT INTO `roles_tasks` (`id`, `user_id`, `role_id`, `task_id`, `project_id`, `company_id`, `created_at`, `updated_at`) VALUES
(1, 1, 2, 1, 1, 1, NULL, NULL),
(2, 2, 3, 1, 1, 1, NULL, NULL),
(3, 1, 2, 2, 1, 1, NULL, NULL),
(4, 2, 3, 2, 1, 1, NULL, NULL),
(5, 1, 2, 3, 2, 1, NULL, NULL),
(6, 2, 3, 3, 2, 1, NULL, NULL),
(7, 1, 2, 4, 2, 1, NULL, NULL),
(8, 2, 3, 4, 2, 1, NULL, NULL),
(9, 1, 2, 5, 3, 1, NULL, NULL),
(10, 2, 3, 5, 3, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--

CREATE TABLE `tasks` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `time` int NOT NULL,
  `fact_time` int NOT NULL,
  `price` int NOT NULL,
  `limit` int NOT NULL,
  `importance` int NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `status_id` bigint UNSIGNED NOT NULL DEFAULT '1',
  `project_id` bigint UNSIGNED NOT NULL,
  `company_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `text`, `time`, `fact_time`, `price`, `limit`, `importance`, `is_active`, `status_id`, `project_id`, `company_id`, `created_at`, `updated_at`) VALUES
(1, 'Создание списка задач в виде канбан', '0', 1, 1, 1, 1, 100, 1, 2, 1, 1, '2021-05-24 01:46:52', NULL),
(2, 'Реализовать переключение вида задач', '0', 1, 1, 1, 1, 100, 1, 1, 1, 1, '2021-05-24 01:46:52', NULL),
(3, 'Копирование и установка акции счастливый час', '0', 1, 1, 1, 1, 90, 1, 4, 2, 1, '2021-05-24 01:46:52', NULL),
(4, 'Установка акции счастливый 2020', '0', 1, 1, 1, 1, 80, 1, 4, 2, 1, '2021-05-24 01:46:52', NULL),
(5, 'Не меняются баннеры в приложении', '0', 1, 1, 1, 1, 70, 1, 3, 3, 1, '2021-05-24 01:46:52', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `task_status`
--

CREATE TABLE `task_status` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `task_status`
--

INSERT INTO `task_status` (`id`, `name`, `is_active`, `code`, `created_at`, `updated_at`) VALUES
(1, 'Бэклог', 1, '0AEX6rmEqNOddBgjsGihmVtNVCDl5WC3uN8OIIt7T8FPmZzzSk', NULL, NULL),
(2, 'В работе', 1, 'HxrsVt8jyVN8zaT197QwsMTWvcUobrCmpKHB4Eo85QvjN7azcl', NULL, NULL),
(3, 'Проверка', 1, 'JL170XUkYBUJdcRQveMx86eKT1xK8DvDHpbAO9WPIE1IPTc93l', NULL, NULL),
(4, 'Готово', 1, '0skW7PF0MMnQ40sC7HmdT4SMBpW69dP7J3tF7GtH2EK4xw9WIy', NULL, NULL),
(5, 'Архив', 1, 'YCG7lB8FqbWdFPP0PJywbPiySbJObESRQyK8YNjGM3Zn4eAz4h', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `task_timer`
--

CREATE TABLE `task_timer` (
  `id` bigint UNSIGNED NOT NULL,
  `time` int NOT NULL,
  `user_id` bigint UNSIGNED NOT NULL,
  `task_id` bigint UNSIGNED NOT NULL,
  `project_id` bigint UNSIGNED NOT NULL,
  `company_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_id` bigint UNSIGNED NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `phone`, `company_id`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'admin@admin.com', NULL, '89442555578', 1, '$2y$10$T0QNX8jn73J4t9.INGHOneAPgs.UgaAGZTQWgGegM5xRJXhVgZG2G', NULL, NULL, NULL),
(2, 'Максим П.', 'Max@Max.com', NULL, '89452888578', 1, '$2y$10$ln9PfKDJwVarhavImDDL6.BlONOiDsbZaNPiE84vNfou4aMogjf8e', NULL, NULL, NULL),
(3, 'Sergey', 'Sergey@Sergey.com', NULL, '89662868520', 2, '$2y$10$VVGQoV9mhr0gnconktGYa.ssmk4VNow6ppadDFn332uGPY09FGrY2', NULL, NULL, NULL),
(4, 'Andrey', 'Andrey@Andrey.com', NULL, '89588688578', 2, '$2y$10$yUP2VDD.V49ACiu2cLweSOoWafdQqCdOQE8mhSEmHHwUIGEmhtXrG', NULL, NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Индексы таблицы `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `roles_tasks`
--
ALTER TABLE `roles_tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `task_status`
--
ALTER TABLE `task_status`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `task_timer`
--
ALTER TABLE `task_timer`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_name_unique` (`name`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `companies`
--
ALTER TABLE `companies`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT для таблицы `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `roles_tasks`
--
ALTER TABLE `roles_tasks`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `task_status`
--
ALTER TABLE `task_status`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `task_timer`
--
ALTER TABLE `task_timer`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
